/* SPDX-License-Identifier: GPL-2.0+ */
/*
 * Copyright 2015, Freescale Semiconductor
 */

#ifndef _ASM_ARMV8_FSL_LAYERSCAPE_MMU_H_
#define _ASM_ARMV8_FSL_LAYERSCAPE_MMU_H_
void update_early_mmu_table(void);
#endif /* _ASM_ARMV8_FSL_LAYERSCAPE_MMU_H_ */
